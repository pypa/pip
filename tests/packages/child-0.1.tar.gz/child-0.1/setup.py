from distutils.core import setup
setup(
    name='child',
    version='0.1',
    packages=['child', 'parent.plugins'])
