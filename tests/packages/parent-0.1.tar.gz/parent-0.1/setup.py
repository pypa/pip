from distutils.core import setup
setup(
    name='parent',
    version='0.1',
    packages=['parent', 'parent.plugins'])
