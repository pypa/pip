from distutils.core import setup
import sys

class FakeError(Exception):
    pass

if sys.argv[1] == 'install':
    raise FakeError('this package designed to fail on install')

setup(name='broken',
      version='0.2broken',
      py_modules=['broken'],
      )

