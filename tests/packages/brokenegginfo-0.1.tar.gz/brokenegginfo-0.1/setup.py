from setuptools import setup
import sys

class FakeError(Exception):
    pass

if sys.argv[1] == 'egg_info':
    raise FakeError('this package designed to fail on egg_info')

setup(name='brokenegginfo',
      version='0.1',
      py_modules=['brokenegginfo'],
      )

