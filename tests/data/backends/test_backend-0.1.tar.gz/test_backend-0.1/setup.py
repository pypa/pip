from setuptools import setup

setup(
    name="test_backend",
    version="0.1",
    py_modules=["test_backend"]
)
