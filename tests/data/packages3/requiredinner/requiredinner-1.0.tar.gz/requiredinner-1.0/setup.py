#!/usr/bin/env python
from setuptools import setup, find_packages

setup(name='requiredinner',
      version='1.0',
      install_requires = ['dinner'],
      packages=find_packages()
      )
