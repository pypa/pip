from distutils.core import setup
import sys

class FakeError(Exception):
    pass

setup(name='wheelbrokenafter',
      version='0.1',
      scripts=['script.py'],
      )

if sys.argv[1] == 'bdist_wheel':
    # We fail afterwards so that we leave our build artifacts lying around.
    raise FakeError('this package designed to fail AFTER bdist_wheel')
