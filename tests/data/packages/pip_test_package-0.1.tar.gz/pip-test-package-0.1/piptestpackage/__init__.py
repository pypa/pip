# Example package with a console entry point

def main():
    print "Hello World"
