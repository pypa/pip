__version__ = '1.2.0'

#### other stuff ###

def main():
    """Entry point for the application script"""
    print("Call your main application code here")
