from setuptools import setup

setup(name='pep518_twin_forkbombs_first',
      version='234',
      py_modules=['pep518_twin_forkbombs_first'])
