#!/usr/bin/env python
from setuptools import setup, find_packages

setup(
    name='application',
    version='1.9',
    packages=find_packages(),
)
