#!/usr/bin/env python
from setuptools import setup, find_packages

setup(name='require_simple',
      version='1.0',
      install_requires=["simple>=2.0"],
      packages=find_packages()
      )
