from distutils.core import setup

setup(name='broken',
      version='0.1',
      py_modules=['broken'],
      )
