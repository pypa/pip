from distutils.core import setup
import sys

class FakeError(Exception):
    pass

if sys.argv[1] == 'bdist_wheel':
    raise FakeError('this package designed to fail on bdist_wheel')

setup(name='wheelbroken',
      version='0.1',
      py_modules=['broken'],
      )

