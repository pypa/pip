from setuptools import setup

setup(name='pep518_forkbomb',
      version='235',
      py_modules=['pep518_forkbomb'])
