#!/usr/bin/env python
from setuptools import setup, find_packages

setup(
    name='requirement',
    version='1.7',
    packages=find_packages()
)
