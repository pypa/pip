#!/usr/bin/env python
from setuptools import setup, find_packages

setup(
    name='application',
    version='2.1',
    packages=find_packages(),
    install_requires=['requirement>=1.6']
)
