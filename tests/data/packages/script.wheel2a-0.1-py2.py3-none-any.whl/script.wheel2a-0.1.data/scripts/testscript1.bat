rem should be unchanged
echo Hello, world
