from setuptools import setup

setup(
    name="singlemodule",
    version='0.0.0',
    description="A sample Python project with a single module",
    py_modules=['singlemodule'],
)
