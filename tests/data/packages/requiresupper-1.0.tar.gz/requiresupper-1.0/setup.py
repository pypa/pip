#!/usr/bin/env python
from setuptools import setup, find_packages

setup(name='requiresupper',
      version='1.0',
      install_requires = ['upper'],
      packages=find_packages()
      )
