#!python
# EASY-INSTALL-ENTRY-SCRIPT: 'script.wheel1==0.1','console_scripts','t1'
__requires__ = 'script.wheel1==0.1'
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.exit(
        load_entry_point('script.wheel1==0.1', 'console_scripts', 't1')()
    )
