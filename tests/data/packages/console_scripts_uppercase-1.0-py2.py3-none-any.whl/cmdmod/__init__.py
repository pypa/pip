
def cmd():
    print("Hello world!")
