#!/usr/bin/env python
import os
import sys
import json
from setuptools import setup, find_packages

kw = {
    'name': 'setuppyargs',
    'version': '1.0',
    'py_modules': 'dummymodule.py',
}

try:
    setup(**kw)
finally:
    args = json.dumps(sys.argv[1:])
    dest = os.environ.get('PIPTEST_SETUPPYARGS_FILE')
    if dest:
        open(dest, 'w').write(args)
    else:
        msg = 'setup.py args: %s\n' % args
        sys.stdout.write(msg)
