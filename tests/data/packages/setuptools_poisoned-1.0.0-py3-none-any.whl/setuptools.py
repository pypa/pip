raise ImportError("this 'setuptools' was intentionally poisoned")
