#!/usr/bin/env python
from setuptools import setup, find_packages

setup(name='simple',
      version='3.1rc0',
      packages=find_packages()
      )
